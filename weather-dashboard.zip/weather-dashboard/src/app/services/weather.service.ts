import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { WeatherApiResponse } from '../models/weather.model';

@Injectable({ providedIn: 'root' })
export class WeatherService {
  constructor(private http: HttpClient) {}

  /**
   * Fetches current weather for a city/country query string.
   * WeatherAPI's `q` param accepts a city name, "lat,lon", or a country name.
   */
  getCurrentWeather(query: string): Observable<WeatherApiResponse> {
    const params = new HttpParams()
      .set('key', environment.weatherApiKey)
      .set('q', query)
      .set('aqi', 'no');

    return this.http.get<WeatherApiResponse>(
      `${environment.weatherApiBaseUrl}/current.json`,
      { params }
    );
  }
}
