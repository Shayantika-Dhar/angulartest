export interface WeatherApiResponse {
  location: {
    name: string;
    region: string;
    country: string;
    localtime: string;
  };
  current: {
    temp_c: number;
    temp_f: number;
    condition: {
      text: string;
      icon: string;
      code: number;
    };
    humidity: number;
    wind_kph: number;
    feelslike_c: number;
    uv: number;
  };
}

export interface CountryWeather {
  /** Display label for the box, e.g. "Japan" */
  countryLabel: string;
  /** Query sent to WeatherAPI, e.g. "Tokyo" */
  query: string;
  data: WeatherApiResponse | null;
  loading: boolean;
  error: string | null;
}
