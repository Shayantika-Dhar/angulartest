import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { WeatherService } from './services/weather.service';
import { CountryWeather } from './models/weather.model';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent implements OnInit {
  // Edit this list to change which countries appear — `query` is what's sent to WeatherAPI
  // (a capital city gives more reliable results than a bare country name).
  countries: CountryWeather[] = [
    { countryLabel: 'Japan', query: 'Tokyo', data: null, loading: true, error: null },
    { countryLabel: 'United Kingdom', query: 'London', data: null, loading: true, error: null },
    { countryLabel: 'United States', query: 'New York', data: null, loading: true, error: null },
    { countryLabel: 'Australia', query: 'Sydney', data: null, loading: true, error: null },
    { countryLabel: 'Brazil', query: 'Rio de Janeiro', data: null, loading: true, error: null },
    { countryLabel: 'India', query: 'Mumbai', data: null, loading: true, error: null },
  ];

  lastUpdated: Date | null = null;
  isRefreshing = false;
  hasConfiguredKey = true;

  constructor(private weatherService: WeatherService) {}

  ngOnInit(): void {
    this.loadAll();
  }

  loadAll(): void {
    this.isRefreshing = true;
    this.countries.forEach((c) => {
      c.loading = true;
      c.error = null;
    });

    let remaining = this.countries.length;
    const done = () => {
      remaining -= 1;
      if (remaining <= 0) {
        this.isRefreshing = false;
        this.lastUpdated = new Date();
      }
    };

    this.countries.forEach((country) => {
      this.weatherService.getCurrentWeather(country.query).subscribe({
        next: (res) => {
          country.data = res;
          country.loading = false;
          done();
        },
        error: (err) => {
          country.loading = false;
          if (err?.status === 401 || err?.status === 403) {
            this.hasConfiguredKey = false;
            country.error = 'API key missing or invalid';
          } else {
            country.error = 'Could not load weather';
          }
          done();
        },
      });
    });
  }

  refresh(): void {
    if (this.isRefreshing) return;
    this.loadAll();
  }

  trackByLabel(_index: number, item: CountryWeather): string {
    return item.countryLabel;
  }
}
