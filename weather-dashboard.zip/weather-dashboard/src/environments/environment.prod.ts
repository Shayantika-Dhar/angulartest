export const environment = {
  production: true,
  weatherApiKey: 'YOUR_WEATHERAPI_KEY',
  weatherApiBaseUrl: 'https://api.weatherapi.com/v1',
};
