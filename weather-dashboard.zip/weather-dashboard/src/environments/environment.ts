export const environment = {
  production: false,
  // Get a free key at https://www.weatherapi.com/ (Sign Up → Dashboard → API Key)
  weatherApiKey: 'YOUR_WEATHERAPI_KEY',
  weatherApiBaseUrl: 'https://api.weatherapi.com/v1',
};
